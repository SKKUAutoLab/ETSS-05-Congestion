# Crowd Locater
This is a crowd locater for SenseCrowd dataset with HRNet-W48.
The weight can be download from  https://pan.baidu.com/s/1-E2FSNCM3336M4YmL9lwQQ passwd: wypa 