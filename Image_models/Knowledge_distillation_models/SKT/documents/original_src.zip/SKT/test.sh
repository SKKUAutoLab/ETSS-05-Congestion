python test.py A_test.json \
	-c '/model/file' \
	-v quarter_vgg
