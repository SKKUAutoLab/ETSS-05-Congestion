# Copyright (c) OpenMMLab. All rights reserved.
from .yolov5_optim_constructor import YOLOv5OptimizerConstructor

__all__ = ['YOLOv5OptimizerConstructor']
