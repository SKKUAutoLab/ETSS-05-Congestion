部署必备教程
************************

.. toctree::
   :maxdepth: 1

   basic_deployment_guide.md


部署全流程说明
************************

.. toctree::
   :maxdepth: 1

   yolov5_deployment.md
