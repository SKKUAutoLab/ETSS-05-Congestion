Basic Deployment Guide
************************

.. toctree::
   :maxdepth: 1

   basic_deployment_guide.md


Deployment tutorial
************************

.. toctree::
   :maxdepth: 1

   yolov5_deployment.md
