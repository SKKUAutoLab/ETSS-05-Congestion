Essential Basics
********************

.. toctree::
   :maxdepth: 1

   model_design.md


Algorithm principles and implementation
******************************************

.. toctree::
   :maxdepth: 1

   yolov5_description.md
