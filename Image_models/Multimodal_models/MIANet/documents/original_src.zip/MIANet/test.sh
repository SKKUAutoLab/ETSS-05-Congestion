python test.py \
    --data-dir /path/to/preprocessed/dataset \
    --save-dir /path/to/saved/model \
    --model "model_name" \
    --device 0
