#  
We follow the official code of [Cross-Modal Collaborative Representation Learning and a Large-Scale RGBT Benchmark for Crowd Counting]
(https://github.com/chen-judge/RGBTCrowdCounting/tree/main/BL%2BIADM%20for%20RGBT%20Crowd%20Counting) 
and add our model SCANet and its variants in the models folder, SCANet_v7 is the code of our model



train.py file and the corresponding training data set, model files have been given, just need to confirm the running environment to run
test.py file only needs to confirm the path of the test set and can be run.

```

