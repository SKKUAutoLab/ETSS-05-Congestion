import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable

from models.matcher import HungarianMatcher_Crowd
import torch.distributed as dist
def is_dist_avail_and_initialized():
    if not dist.is_available():
        return False
    if not dist.is_initialized():
        return False
    return True
def get_world_size():
    if not is_dist_avail_and_initialized():
        return 1
    return dist.get_world_size()

class Focal_L1(nn.Module):
    def __init__(self):
        super(Focal_L1, self).__init__()
        self.epsilon=torch.tensor(0.5)
    def forward(self, x, y):
        if isinstance(x, (float, int)): x = Variable(torch.Tensor([x]))
        if isinstance(y, (float, int)): y = Variable(torch.Tensor([y]))
        # x=Variable(x)
        # (predict_cnt - gt_cnt) * abs(torch.log2(abs(predict_cnt - gt_cnt) / (gt_cnt + 1e-6)))
        # m=torch.abs(torch.mul((x-y),(torch.sqrt(torch.abs(x-y)/(y+self.epsilon)))))
        # mse_loss = torch.mean(torch.abs(torch.mul((x-y),(torch.sqrt(torch.abs(x-y)/(y+self.epsilon))))))
        mse_loss=torch.mul(torch.abs(x-y)/(y+self.epsilon),torch.log2(F.mse_loss(x, y, reduction='none')+1))

        return mse_loss

class SetCriterion_Crowd(nn.Module):

    def __init__(self, num_classes, matcher, weight_dict, eos_coef, losses):
        """ Create the criterion.
        Parameters:
            num_classes: number of object categories, omitting the special no-object category
            matcher: module able to compute a matching between targets and proposals
            weight_dict: dict containing as key the names of the losses and as values their relative weight.
            eos_coef: relative classification weight applied to the no-object category
            losses: list of all the losses to be applied. See get_loss for list of available losses.
        """
        super().__init__()
        self.num_classes = num_classes
        self.matcher = matcher
        self.weight_dict = weight_dict
        self.eos_coef = eos_coef
        self.losses = losses
        empty_weight = torch.ones(self.num_classes + 1)
        empty_weight[0] = self.eos_coef
        self.register_buffer('empty_weight', empty_weight)
        self.device = "cuda" if torch.cuda.is_available() else "cpu"

    def loss_labels(self, outputs, targets, indices, num_points):
        """Classification loss (NLL)
        targets dicts must contain the key "labels" containing a tensor of dim [nb_target_boxes]
        """
        assert 'pred_logits' in outputs
        src_logits = outputs['pred_logits']

        idx = self._get_src_permutation_idx(indices)
        target_classes_o = torch.cat([t["labels"][J] for t, (_, J) in zip(targets, indices)])
        target_classes = torch.full(src_logits.shape[:2], 0,
                                    dtype=torch.int64, device=src_logits.device)
        target_classes[idx] = target_classes_o

        loss_ce = F.cross_entropy(src_logits.transpose(1, 2), target_classes, self.empty_weight)
        losses = {'loss_ce': loss_ce}

        return losses

    def loss_points(self, outputs, targets, indices, num_points):

        assert 'pred_points' in outputs
        idx = self._get_src_permutation_idx(indices)
        src_points = outputs['pred_points'][idx]
        target_points = torch.cat([t['point'][i] for t, (_, i) in zip(targets, indices)], dim=0)

        loss_bbox = F.mse_loss(src_points, target_points, reduction='none')

        losses = {}
        losses['loss_point'] = loss_bbox.sum() / num_points

        return losses
    def loss_nums(self, outputs, targets, indices, num_points):
        outputs_scores = torch.nn.functional.softmax(outputs['pred_logits'], -1)[:, :, 1]
        threshold = 0.5
        predict_cnt=sum(int((t > threshold).sum()) for t in outputs_scores)
        # outputs_points = outputs['pred_points'][0]

        # gt_cnt = targets[0]['point'].shape[0]
        # 0.5 is used by default
        # threshold = 0.5
        # idx = self._get_src_permutation_idx(indices)

        # predict_cnt = sum(int(t.sum()) for t in targets['point'])

        # accumulate MAE, MSE
        focal_l1=Focal_L1()
        focal_l1.to(self.device)
        loss=focal_l1(predict_cnt,num_points)
        losses = {}
        losses['loss_nums'] =loss.to(self.device)
        # mae = abs(predict_cnt - gt_cnt)
        return losses

    def _get_src_permutation_idx(self, indices):
        # permute predictions following indices
        batch_idx = torch.cat([torch.full_like(src, i) for i, (src, _) in enumerate(indices)])
        src_idx = torch.cat([src for (src, _) in indices])
        return batch_idx, src_idx

    def _get_tgt_permutation_idx(self, indices):
        # permute targets following indices
        batch_idx = torch.cat([torch.full_like(tgt, i) for i, (_, tgt) in enumerate(indices)])
        tgt_idx = torch.cat([tgt for (_, tgt) in indices])
        return batch_idx, tgt_idx

    def get_loss(self, loss, outputs, targets, indices, num_points, **kwargs):
        loss_map = {
            'labels': self.loss_labels,
            'points': self.loss_points,
            'nums': self.loss_nums,
        }
        assert loss in loss_map, f'do you really want to compute {loss} loss?'
        return loss_map[loss](outputs, targets, indices, num_points, **kwargs)

    def forward_and_pair(self, outputs, targets):
        output1 = {'pred_logits': outputs['pred_logits'], 'pred_points': outputs['pred_points']}

        indices1 = self.matcher(output1, targets)
        temp=[]
        # idx = self._get_src_permutation_idx(indices1)
        # src_points = outputs['pred_points'][idx]
        # temp=[torch.zeros(p['point'].shape) for p in targets]
        # temp=[[] for i in range(len(targets))]
        # temp_b=0
        # temp_i=0
        # for t, (_, i) in zip(src_points, (zip(idx[0],idx[1]))):
        #     temp[_].append(t)
        # [temp[_].append(t) for t, (_, i) in zip(src_points, (zip(idx[0],idx[1])))]
        # print(src_p)
        # for b,i in list(zip(idx[0],idx[1])):
        #     if temp_b!=b:
        #         temp_b = b
        #         temp_i=0
        #     src_p[b][i]=outputs['pred_points'][b][i]
        #     temp_i+=1
        # target_points = torch.cat([t['point'][i] for t, (_, i) in zip(targets, indices1)], dim=0)
        num_points = sum(len(t["labels"]) for t in targets)
        num_points = torch.as_tensor([num_points], dtype=torch.float, device=next(iter(output1.values())).device)
        threshold=0.5
        outputs_scores = torch.nn.functional.softmax(outputs['pred_logits'], -1)[:, :, 1]
        mask=outputs_scores>threshold
        for i in range(outputs_scores.shape[0]):
            temp.append(outputs['pred_points'][i][mask[i]])
            # pass
        # temp=outputs['pred_points'][mask]
        if is_dist_avail_and_initialized():
            torch.distributed.all_reduce(num_points)
        num_boxes = torch.clamp(num_points / get_world_size(), min=1).item()

        losses = {}
        for loss in self.losses:
            losses.update(self.get_loss(loss, output1, targets, indices1, num_boxes))

        return losses,temp
    def forward(self, outputs, targets):
        """ This performs the loss computation.
        Parameters:
             outputs: dict of tensors, see the output specification of the model for the format
             targets: list of dicts, such that len(targets) == batch_size.
                      The expected keys in each dict depends on the losses applied, see each loss' doc
        """
        output1 = {'pred_logits': outputs['pred_logits'], 'pred_points': outputs['pred_points']}

        indices1 = self.matcher(output1, targets)

        num_points = sum(len(t["labels"]) for t in targets)
        num_points = torch.as_tensor([num_points], dtype=torch.float, device=next(iter(output1.values())).device)
        if is_dist_avail_and_initialized():
            torch.distributed.all_reduce(num_points)
        num_boxes = torch.clamp(num_points / get_world_size(), min=1).item()

        losses = {}
        for loss in self.losses:
            losses.update(self.get_loss(loss, output1, targets, indices1, num_boxes))

        return losses


def criterion():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    num_classes = 1
    matcher=HungarianMatcher_Crowd()
    weight_dict = {'loss_ce': 1, 'loss_points': 0.05, 'loss_nums': 0.05}
    losses = ['labels', 'points','nums']
    criterion = SetCriterion_Crowd(num_classes, \
                                   matcher=matcher, weight_dict=weight_dict, \
                                   eos_coef=0.5, losses=losses)
    return criterion.to(device)