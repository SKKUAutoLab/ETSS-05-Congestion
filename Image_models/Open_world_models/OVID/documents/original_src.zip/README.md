# OVID: Open-Vocabulary Image-text Dense Framework for Counting and Localization


> **OVID (Open-Vocabulary Image-text Dense Framework for Counting and Localization)** is the first unified framework designed to seamlessly integrate object counting and localization driven by textual queries within a single, end-to-end trainable architecture.

## 🔥 Highlights

- **🚀 First Unified Framework**: Seamlessly integrates object counting and localization in a single end-to-end architecture
- **🎯 Point-Level Prediction**: Predicts precise point coordinates for each object instance, enabling fine-grained spatial localization
- **💡 MAFT Architecture**: Novel Multi-Attention Fusion Transformer that effectively fuses multi-modal features while preserving local information
- **📝 Open-Vocabulary**: Supports natural language descriptions for flexible object category specification
- **⚡ State-of-the-Art Performance**: Achieves superior results on FSC147 and ShanghaiTech benchmarks

## 📋 Abstract

Object counting and localization within dense scenes, particularly when categories are specified via open-vocabulary text descriptions, remains a critical yet challenging task. Real-world applications demand simultaneous precise localization and counting capabilities guided by natural language, yet existing methods often struggle with complex visual scenarios or necessitate separate models for tasks like counting and localization, lacking a unified framework to handle these intertwined challenges. 

We present **OVID (Open-Vocabulary Image-text Dense Framework for Counting and Localization)**, the first unified framework designed to seamlessly integrate object counting and localization driven by textual queries within a single, end-to-end trainable architecture. Unlike approaches relying on global features or density maps, OVID predicts point coordinates for each object instance, enabling fine-grained alignment between visual and textual representations fundamental for accurate spatial localization and subsequent counting.

## 🏗️ Architecture

### Core Components

1. **OVID Model**: Main unified framework combining CLIP encoder with specialized decoders
2. **MAFT (Multi-Attention Fusion Transformer)**: Key module for effective multi-modal feature fusion
3. **Dual-branch Decoder**: Regression and classification branches for point-level prediction

### Key Features

- **Point-based Prediction**: Direct coordinate prediction instead of density map estimation
- **Multi-modal Fusion**: Advanced attention mechanisms for visual-textual alignment
- **Unified Loss Function**: Multi-task optimization for both counting and localization
- **End-to-end Training**: Single architecture handling both tasks simultaneously

## 🚀 Quick Start

### Installation

#### Option 1: Using pip

```bash
# Clone the repository
git clone https://github.com/your-username/OVID.git
cd OVID

# Create virtual environment
python -m venv ovid_env
source ovid_env/bin/activate  # On Windows: ovid_env\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# For minimal installation (core dependencies only)
# pip install -r requirements-minimal.txt
```

#### Option 2: Using conda

```bash
# Clone the repository
git clone https://anonymous.4open.science/r/OVID-5035.git
cd OVID

# Create conda environment from yml file
conda env create -f environment.yml
conda activate ovid
```

#### Option 3: Manual installation

```bash
# Create conda environment
conda create -n ovid python=3.8
conda activate ovid

# Install PyTorch (check https://pytorch.org for your specific CUDA version)
pip install torch torchvision torchaudio

# Install other dependencies
pip install pytorch-lightning opencv-python scipy einops pillow imgaug matplotlib tqdm
pip install git+https://github.com/openai/CLIP.git
```

#### Option 4: Development installation

```bash
# Clone the repository
git clone https://anonymous.4open.science/r/OVID-5035.git
cd OVID

# Install in development mode
pip install -e .

# Or with all optional dependencies
pip install -e .[full]
```

### Prepare Datasets

1. **FSC147 Dataset**:
   ```bash
   # Download FSC147 dataset from official source
   # Place in ./data/FSC147/
   ```

2. **ShanghaiTech Dataset**:
   ```bash
   # Download ShanghaiTech dataset
   # Place in ./data/ShanghaiTech/
   ```

3. **CLIP Pretrained Weights**:
   ```bash
   # Download CLIP weights and place in ./models/weight/
   # Required: ViT-B-16.pt, ViT-B-32.pt, ViT-L-14-336px.pt
   ```

### Training

```bash
# Train on FSC147 dataset
python run.py --mode train \
              --dataset_type FSC \
              --batch_size 8 \
              --epochs 200 \
              --backbone b16 \
              --exp_name ovid_fsc147

# Train on ShanghaiTech dataset
python run.py --mode train \
              --dataset_type ShanghaiTech \
              --batch_size 8 \
              --epochs 200 \
              --backbone b16 \
              --exp_name ovid_shanghaitech
```

### Testing

```bash
# Test on FSC147
python run.py --mode test \
              --dataset_type FSC \
              --ckpt path/to/checkpoint.ckpt \
              --backbone b16

# Test on ShanghaiTech
python run.py --mode test \
              --dataset_type ShanghaiTech \
              --ckpt path/to/checkpoint.ckpt \
              --backbone b16
```

### Inference

```python
import torch
from models.ovid import OVID

# Load model
model = OVID(backbone='b16', use_mixed_fim=True)
model.load_state_dict(torch.load('path/to/checkpoint.pth'))
model.eval()

# Inference
image = torch.randn(1, 3, 384, 384)  # Your input image
text_prompt = ["cars"]  # Object category description

with torch.no_grad():
    output = model(image, text_prompt)
    predicted_points = output['pred_points']
    predicted_scores = output['pred_logits']
```

## 📊 Results

### FSC147 Dataset

| Method | MAE ↓ | RMSE ↓ |
|--------|-------|--------|
| CLIP-Count | 17.78 | 106.62 |
| **OVID (Ours)** | **15.61** | **98.73** |



## 🛠️ Model Configuration

### Supported Backbones
- `b16`: ViT-B/16 (recommended)

### Key Parameters
- `--use_mixed_fim`: Enable hierarchical feature interaction (recommended: True)
- `--use_vpt`: Enable visual prompt tuning (recommended: True)
- `--use_coop`: Enable context optimization (recommended: True)
- `--use_contrast`: Enable contrastive learning (recommended: True)

## 📁 Project Structure

```
OVID/
├── models/
│   ├── ovid.py              # Main OVID model
│   ├── attention_modules.py  # MAFT and attention mechanisms
│   ├── matcher.py           # Hungarian matcher
│   ├── matcher_loss.py      # Multi-task loss functions
│   └── weight/              # Pretrained CLIP weights
├── datasets/
│   ├── FSC147.py           # FSC147 dataset loader
│   ├── ShanghaiTech.py     # ShanghaiTech dataset loader
│   └── CARPK.py            # CARPK dataset loader
├── util/
│   ├── misc.py             # Utility functions
│   └── pos_embed.py        # Position embedding
├── run.py                  # Main training/testing script
└── README.md
```

## 🎯 Key Innovations

1. **Unified Architecture**: First framework to handle both counting and localization in a single model
2. **Point-Level Prediction**: Direct coordinate prediction for precise localization
3. **MAFT Module**: Multi-Attention Fusion Transformer for effective multi-modal feature fusion
4. **Multi-Task Learning**: Unified optimization strategy for complementary feature learning



## 🤝 Contributing

We welcome contributions! Please feel free to submit a Pull Request.



## 🙏 Acknowledgments

- [CLIP](https://github.com/openai/CLIP) for the powerful vision-language pretrained model
- [PyTorch Lightning](https://pytorch-lightning.readthedocs.io/) for the training framework
- FSC147 and ShanghaiTech dataset providers



⭐ **Star this repo if you find it helpful!** 
