# Counting Splatfacto

This nerfstudio method is almost the same as splatfacto, with the following changes:

* Make `ns-eval` also save depth and accumulation maps.
* Add a click to the viewer to select 3D points, making it easy to measure distances in 3D.
