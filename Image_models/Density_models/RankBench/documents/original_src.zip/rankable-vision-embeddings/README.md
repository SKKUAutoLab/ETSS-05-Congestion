Codebase for the preprint: [**On the Rankability of Visual Embeddings**](https://arxiv.org/abs/2507.03683)  
Ankit Sonthalia, Arnas Uselis, Seong Joon Oh  
**arXiv:2507.03683**, 2025

---

## 🛠 Setup

Create the environment and install dependencies:

```bash
conda create -n rankable python=3.10
conda activate rankable
pip install -e .
```

---

## 🚀 Minimal Working Example

Run the evaluation pipeline with:

```bash
python scripts/eval.py -d -c configs/utkface.yaml
```

More instructions and pre-computed embeddings coming soon!

---

## 📚 Citation

If you use this work, please cite:

```bibtex
@article{sonthalia2025rankability,
  title={On the Rankability of Visual Embeddings},
  author={Ankit Sonthalia and Arnas Uselis and Seong Joon Oh},
  journal={arXiv preprint arXiv:2507.03683},
  year={2025}
}
```
